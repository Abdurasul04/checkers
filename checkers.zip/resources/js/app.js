function itemSelect() {
    console.log("it works!");
}
//hi